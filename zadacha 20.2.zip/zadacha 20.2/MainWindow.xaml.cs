﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace zadacha_20._2
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Block1_Click(object sender, RoutedEventArgs e)
        {
            if (RadioButtonX.IsChecked == true)
            {
                Block1.Content = "X";
            }
            if(RadioButtonO.IsChecked == true)
            {
                Block1.Content = "O";
            }
                 
            
            if (Block1.Content != null)
            {
                if (Block1.Content == Block2.Content && Block2.Content == Block3.Content)
                {
                    Block1.IsEnabled = false;
                    Block2.IsEnabled = false;
                    Block3.IsEnabled = false;
                    Block4.IsEnabled = false;
                    Block5.IsEnabled = false;
                    Block6.IsEnabled = false;
                    Block7.IsEnabled = false;
                    Block8.IsEnabled = false;
                    Block9.IsEnabled = false;

                    MessageBox.Show("You win");
                }
                else if (Block1.Content == Block4.Content && Block4.Content == Block7.Content)
                {
                    Block1.IsEnabled = false;
                    Block2.IsEnabled = false;
                    Block3.IsEnabled = false;
                    Block4.IsEnabled = false;
                    Block5.IsEnabled = false;
                    Block6.IsEnabled = false;
                    Block7.IsEnabled = false;
                    Block8.IsEnabled = false;
                    Block9.IsEnabled = false;

                    MessageBox.Show("You win");
                }
                else if (Block1.Content == Block5.Content && Block5.Content == Block9.Content)
                {
                    Block1.IsEnabled = false;
                    Block2.IsEnabled = false;
                    Block3.IsEnabled = false;
                    Block4.IsEnabled = false;
                    Block5.IsEnabled = false;
                    Block6.IsEnabled = false;
                    Block7.IsEnabled = false;
                    Block8.IsEnabled = false;
                    Block9.IsEnabled = false;

                    MessageBox.Show("You win");
                }
                else if (Block1.Content != null && Block2.Content != null && Block3.Content != null && Block4.Content != null && Block5.Content != null && Block6.Content != null && Block7.Content != null && Block8.Content != null && Block9.Content != null)
                {
                    MessageBox.Show("Ничья");
                }

            }
        }

        private void Block2_Click(object sender, RoutedEventArgs e)
        {
            if (RadioButtonX.IsChecked == true)
            {
                Block2.Content = "X";
            }
            if (RadioButtonO.IsChecked == true)
            {
                Block2.Content = "O";
            }


            if (Block2.Content != null)
            {
                if (Block1.Content == Block2.Content && Block2.Content == Block3.Content)
                {
                    Block1.IsEnabled = false;
                    Block2.IsEnabled = false;
                    Block3.IsEnabled = false;
                    Block4.IsEnabled = false;
                    Block5.IsEnabled = false;
                    Block6.IsEnabled = false;
                    Block7.IsEnabled = false;
                    Block8.IsEnabled = false;
                    Block9.IsEnabled = false;

                    MessageBox.Show("You win");
                }
                else if (Block2.Content == Block5.Content && Block5.Content == Block8.Content)
                {
                    Block1.IsEnabled = false;
                    Block2.IsEnabled = false;
                    Block3.IsEnabled = false;
                    Block4.IsEnabled = false;
                    Block5.IsEnabled = false;
                    Block6.IsEnabled = false;
                    Block7.IsEnabled = false;
                    Block8.IsEnabled = false;
                    Block9.IsEnabled = false;

                    MessageBox.Show("You win");
                }
                else if (Block1.Content != null && Block2.Content != null && Block3.Content != null && Block4.Content != null && Block5.Content != null && Block6.Content != null && Block7.Content != null && Block8.Content != null && Block9.Content != null)
                {
                    MessageBox.Show("Ничья");
                }

            }
        }

        private void Block3_Click(object sender, RoutedEventArgs e)
        {
            if (RadioButtonX.IsChecked == true)
            {
                Block3.Content = "X";
            }
            if (RadioButtonO.IsChecked == true)
            {
                Block3.Content = "O";
            }


            if (Block3.Content != null)
            {
                if (Block1.Content == Block2.Content && Block2.Content == Block3.Content)
                {
                    Block1.IsEnabled = false;
                    Block2.IsEnabled = false;
                    Block3.IsEnabled = false;
                    Block4.IsEnabled = false;
                    Block5.IsEnabled = false;
                    Block6.IsEnabled = false;
                    Block7.IsEnabled = false;
                    Block8.IsEnabled = false;
                    Block9.IsEnabled = false;

                    MessageBox.Show("You win");
                }
                else if (Block3.Content == Block6.Content && Block6.Content == Block9.Content)
                {
                    Block1.IsEnabled = false;
                    Block2.IsEnabled = false;
                    Block3.IsEnabled = false;
                    Block4.IsEnabled = false;
                    Block5.IsEnabled = false;
                    Block6.IsEnabled = false;
                    Block7.IsEnabled = false;
                    Block8.IsEnabled = false;
                    Block9.IsEnabled = false;

                    MessageBox.Show("You win");
                }
                else if (Block3.Content == Block5.Content && Block5.Content == Block7.Content)
                {
                    Block1.IsEnabled = false;
                    Block2.IsEnabled = false;
                    Block3.IsEnabled = false;
                    Block4.IsEnabled = false;
                    Block5.IsEnabled = false;
                    Block6.IsEnabled = false;
                    Block7.IsEnabled = false;
                    Block8.IsEnabled = false;
                    Block9.IsEnabled = false;

                    MessageBox.Show("You win");
                }
                else if (Block1.Content != null && Block2.Content != null && Block3.Content != null && Block4.Content != null && Block5.Content != null && Block6.Content != null && Block7.Content != null && Block8.Content != null && Block9.Content != null)
                {
                    MessageBox.Show("Ничья");
                }
            }
        }

        private void Block4_Click(object sender, RoutedEventArgs e)
        {
            if (RadioButtonX.IsChecked == true)
            {
                Block4.Content = "X";
            }
            if (RadioButtonO.IsChecked == true)
            {
                Block4.Content = "O";
            }

            if (Block4.Content != null)
            {
                if (Block4.Content == Block5.Content && Block5.Content == Block6.Content)
                {
                    Block1.IsEnabled = false;
                    Block2.IsEnabled = false;
                    Block3.IsEnabled = false;
                    Block4.IsEnabled = false;
                    Block5.IsEnabled = false;
                    Block6.IsEnabled = false;
                    Block7.IsEnabled = false;
                    Block8.IsEnabled = false;
                    Block9.IsEnabled = false;

                    MessageBox.Show("You win");
                }
                else if (Block1.Content == Block4.Content && Block4.Content == Block7.Content)
                {
                    Block1.IsEnabled = false;
                    Block2.IsEnabled = false;
                    Block3.IsEnabled = false;
                    Block4.IsEnabled = false;
                    Block5.IsEnabled = false;
                    Block6.IsEnabled = false;
                    Block7.IsEnabled = false;
                    Block8.IsEnabled = false;
                    Block9.IsEnabled = false;

                    MessageBox.Show("You win");
                }
                else if (Block1.Content != null && Block2.Content != null && Block3.Content != null && Block4.Content != null && Block5.Content != null && Block6.Content != null && Block7.Content != null && Block8.Content != null && Block9.Content != null) { 

                    MessageBox.Show("Ничья");
                }
            }
        }

        private void Block5_Click(object sender, RoutedEventArgs e)
        {
            if (RadioButtonX.IsChecked == true)
            {
                Block5.Content = "X";
            }
            if (RadioButtonO.IsChecked == true)
            {
                Block5.Content = "O";
            }

            if (Block5.Content != null)
            {
                if (Block4.Content == Block5.Content && Block5.Content == Block6.Content)
                {
                    Block1.IsEnabled = false;
                    Block2.IsEnabled = false;
                    Block3.IsEnabled = false;
                    Block4.IsEnabled = false;
                    Block5.IsEnabled = false;
                    Block6.IsEnabled = false;
                    Block7.IsEnabled = false;
                    Block8.IsEnabled = false;
                    Block9.IsEnabled = false;

                    MessageBox.Show("You win");
                }
                else if (Block1.Content == Block5.Content && Block5.Content == Block9.Content)
                {
                    Block1.IsEnabled = false;
                    Block2.IsEnabled = false;
                    Block3.IsEnabled = false;
                    Block4.IsEnabled = false;
                    Block5.IsEnabled = false;
                    Block6.IsEnabled = false;
                    Block7.IsEnabled = false;
                    Block8.IsEnabled = false;
                    Block9.IsEnabled = false;

                    MessageBox.Show("You win");
                }
                else if (Block3.Content == Block5.Content && Block5.Content == Block7.Content)
                {
                    Block1.IsEnabled = false;
                    Block2.IsEnabled = false;
                    Block3.IsEnabled = false;
                    Block4.IsEnabled = false;
                    Block5.IsEnabled = false;
                    Block6.IsEnabled = false;
                    Block7.IsEnabled = false;
                    Block8.IsEnabled = false;
                    Block9.IsEnabled = false;

                    MessageBox.Show("You win");
                }
                else if (Block1.Content != null && Block2.Content != null && Block3.Content != null && Block4.Content != null && Block5.Content != null && Block6.Content != null && Block7.Content != null && Block8.Content != null && Block9.Content != null)
            {
                    MessageBox.Show("Ничья");
                }
            }
        }

        private void Block6_Click(object sender, RoutedEventArgs e)
        {
            if (RadioButtonX.IsChecked == true)
            {
                Block6.Content = "X";
            }
            if (RadioButtonO.IsChecked == true)
            {
                Block6.Content = "O";
            }

            if (Block6.Content != null)
            {
                if (Block4.Content == Block5.Content && Block5.Content == Block6.Content)
                {
                    Block1.IsEnabled = false;
                    Block2.IsEnabled = false;
                    Block3.IsEnabled = false;
                    Block4.IsEnabled = false;
                    Block5.IsEnabled = false;
                    Block6.IsEnabled = false;
                    Block7.IsEnabled = false;
                    Block8.IsEnabled = false;
                    Block9.IsEnabled = false;

                    MessageBox.Show("You win");
                }
                else if (Block3.Content == Block6.Content && Block6.Content == Block9.Content)
                {
                    Block1.IsEnabled = false;
                    Block2.IsEnabled = false;
                    Block3.IsEnabled = false;
                    Block4.IsEnabled = false;
                    Block5.IsEnabled = false;
                    Block6.IsEnabled = false;
                    Block7.IsEnabled = false;
                    Block8.IsEnabled = false;
                    Block9.IsEnabled = false;

                    MessageBox.Show("You win");
                }
                else if (Block1.Content != null && Block2.Content != null && Block3.Content != null && Block4.Content != null && Block5.Content != null && Block6.Content != null && Block7.Content != null && Block8.Content != null && Block9.Content != null)
                {
                    MessageBox.Show("Ничья");
                }
            }
        }

        private void Block7_Click(object sender, RoutedEventArgs e)
        {
            if (RadioButtonX.IsChecked == true)
            {
                Block7.Content = "X";
            }
            if (RadioButtonO.IsChecked == true)
            {
                Block7.Content = "O";
            }

            if (Block7.Content != null)
            {
                if (Block7.Content == Block8.Content && Block8.Content == Block9.Content)
                {
                    Block1.IsEnabled = false;
                    Block2.IsEnabled = false;
                    Block3.IsEnabled = false;
                    Block4.IsEnabled = false;
                    Block5.IsEnabled = false;
                    Block6.IsEnabled = false;
                    Block7.IsEnabled = false;
                    Block8.IsEnabled = false;
                    Block9.IsEnabled = false;

                    MessageBox.Show("You win");
                }
                else if (Block1.Content == Block4.Content && Block4.Content == Block7.Content)
                {
                    Block1.IsEnabled = false;
                    Block2.IsEnabled = false;
                    Block3.IsEnabled = false;
                    Block4.IsEnabled = false;
                    Block5.IsEnabled = false;
                    Block6.IsEnabled = false;
                    Block7.IsEnabled = false;
                    Block8.IsEnabled = false;
                    Block9.IsEnabled = false;

                    MessageBox.Show("You win");
                }
                else if (Block3.Content == Block5.Content && Block5.Content == Block7.Content)
                {
                    Block1.IsEnabled = false;
                    Block2.IsEnabled = false;
                    Block3.IsEnabled = false;
                    Block4.IsEnabled = false;
                    Block5.IsEnabled = false;
                    Block6.IsEnabled = false;
                    Block7.IsEnabled = false;
                    Block8.IsEnabled = false;
                    Block9.IsEnabled = false;

                    MessageBox.Show("You win");
                }
                else if (Block1.Content != null && Block2.Content != null && Block3.Content != null && Block4.Content != null && Block5.Content != null && Block6.Content != null && Block7.Content != null && Block8.Content != null && Block9.Content != null)
                {
                    MessageBox.Show("Ничья");
                }
            }
        }

        private void Block8_Click(object sender, RoutedEventArgs e)
        {
            if (RadioButtonX.IsChecked == true)
            {
                Block8.Content = "X";
            }
            if (RadioButtonO.IsChecked == true)
            {
                Block8.Content = "O";
            }

            if (Block8.Content != null)
            {
                if (Block7.Content == Block8.Content && Block8.Content == Block9.Content)
                {
                    Block1.IsEnabled = false;
                    Block2.IsEnabled = false;
                    Block3.IsEnabled = false;
                    Block4.IsEnabled = false;
                    Block5.IsEnabled = false;
                    Block6.IsEnabled = false;
                    Block7.IsEnabled = false;
                    Block8.IsEnabled = false;
                    Block9.IsEnabled = false;

                    MessageBox.Show("You win");
                }
                else if (Block2.Content == Block5.Content && Block5.Content == Block8.Content)
                {
                    Block1.IsEnabled = false;
                    Block2.IsEnabled = false;
                    Block3.IsEnabled = false;
                    Block4.IsEnabled = false;
                    Block5.IsEnabled = false;
                    Block6.IsEnabled = false;
                    Block7.IsEnabled = false;
                    Block8.IsEnabled = false;
                    Block9.IsEnabled = false;

                    MessageBox.Show("You win");
                }
                else if (Block1.Content != null && Block2.Content != null && Block3.Content != null && Block4.Content != null && Block5.Content != null && Block6.Content != null && Block7.Content != null && Block8.Content != null && Block9.Content != null)
                {
                    MessageBox.Show("Ничья");
                }
            }
        }

        private void Block9_Click(object sender, RoutedEventArgs e)
        {
            if (RadioButtonX.IsChecked == true)
            {
                Block9.Content = "X";
            }
            if (RadioButtonO.IsChecked == true)
            {
                Block9.Content = "O";
            }

            if (Block9.Content != null)
            {
                if (Block7.Content == Block8.Content && Block8.Content == Block9.Content)
                {
                    Block1.IsEnabled = false;
                    Block2.IsEnabled = false;
                    Block3.IsEnabled = false;
                    Block4.IsEnabled = false;
                    Block5.IsEnabled = false;
                    Block6.IsEnabled = false;
                    Block7.IsEnabled = false;
                    Block8.IsEnabled = false;
                    Block9.IsEnabled = false;

                    MessageBox.Show("You win");
                }
                else if (Block3.Content == Block6.Content && Block6.Content == Block9.Content)
                {
                    Block1.IsEnabled = false;
                    Block2.IsEnabled = false;
                    Block3.IsEnabled = false;
                    Block4.IsEnabled = false;
                    Block5.IsEnabled = false;
                    Block6.IsEnabled = false;
                    Block7.IsEnabled = false;
                    Block8.IsEnabled = false;
                    Block9.IsEnabled = false;

                    MessageBox.Show("You win");
                }
                else if (Block1.Content == Block5.Content && Block5.Content == Block9.Content)
                {
                    Block1.IsEnabled = false;
                    Block2.IsEnabled = false;
                    Block3.IsEnabled = false;
                    Block4.IsEnabled = false;
                    Block5.IsEnabled = false;
                    Block6.IsEnabled = false;
                    Block7.IsEnabled = false;
                    Block8.IsEnabled = false;
                    Block9.IsEnabled = false;

                    MessageBox.Show("You win");
                }
                else if (Block1.Content != null && Block2.Content != null && Block3.Content != null && Block4.Content != null && Block5.Content != null && Block6.Content != null && Block7.Content != null && Block8.Content != null && Block9.Content != null)
                {
                    MessageBox.Show("Ничья");
                }
            }
        }

        private void NewGame_Click(object sender, RoutedEventArgs e)
        {
            Block1.IsEnabled = true;
            Block2.IsEnabled = true;
            Block3.IsEnabled = true;
            Block4.IsEnabled = true;
            Block5.IsEnabled = true;
            Block6.IsEnabled = true;
            Block7.IsEnabled = true;
            Block8.IsEnabled = true;
            Block9.IsEnabled = true;

            Block1.Content = null;
            Block2.Content = null;
            Block3.Content = null;
            Block4.Content = null;
            Block5.Content = null;
            Block6.Content = null;
            Block7.Content = null;
            Block8.Content = null;
            Block9.Content = null;
        }

        private void Zakazat_Click(object sender, RoutedEventArgs e)
        {
            if(Check_CheeseBurger.IsChecked == true)
            {
                checkList.Items.Add($"Чизбургер. Цена за {number_of_Cheeseburger.Text} шт : " + (int.Parse(number_of_Cheeseburger.Text)*60));
            }
            if (Check_GumBurger.IsChecked == true)
            {
                checkList.Items.Add($"Гамбургер. Цена за {number_of_Gumburger.Text} шт : " + (int.Parse(number_of_Gumburger.Text) * 100));
            }
            if (Check_KokaCola.IsChecked == true)
            {
                checkList.Items.Add($"Кока-Кола. Цена за {number_of_KokaCola.Text} шт : " + (int.Parse(number_of_KokaCola.Text) * 70));
            }
            if (Check_Nagetsi.IsChecked == true)
            {
                checkList.Items.Add($"Нагетсы. Цена за {number_of_nagetsi.Text} шт : " + (int.Parse(number_of_nagetsi.Text) * 160));
            }
            checkList.Items.Add((int.Parse(number_of_Cheeseburger.Text) * 60) + (int.Parse(number_of_Gumburger.Text) * 100) + (int.Parse(number_of_KokaCola.Text) * 70) + (int.Parse(number_of_nagetsi.Text) * 160));
        }

        private void Create_flag_Click(object sender, RoutedEventArgs e)
        {
            SolidColorBrush BlueColor = new SolidColorBrush(Color.FromRgb(0, 0, 255));
            SolidColorBrush RedColor = new SolidColorBrush(Color.FromRgb(255, 0, 0));
            SolidColorBrush GreenColor = new SolidColorBrush(Color.FromRgb(0, 255, 0));
            if (blue1.IsChecked == true) first.Background = BlueColor;
            if (red1.IsChecked == true) first.Background = RedColor;
            if (green1.IsChecked == true) first.Background = GreenColor;
            if (blue2.IsChecked == true) second.Background = BlueColor;
            if (red2.IsChecked == true) second.Background = RedColor;
            if (green2.IsChecked == true) second.Background = GreenColor;
            if (blue3.IsChecked == true) third.Background = BlueColor;
            if (red3.IsChecked == true) third.Background = RedColor;
            if (green3.IsChecked == true) third.Background = GreenColor;
        }

        private void startgame_Click(object sender, RoutedEventArgs e)
        {
            Random random = new Random();
            NumberNow.Text = random.Next(0, 30).ToString();
            StepLast.Text = 10.ToString();
            Plus.Content = "+" + random.Next(0, 10);
            Minus.Content = "-" + random.Next(0, 10);
        }

        private void Plus_Click(object sender, RoutedEventArgs e)
        {
            StepLast.Text = (int.Parse(StepLast.Text) - 1).ToString();
        }

        private void Minus_Click(object sender, RoutedEventArgs e)
        {
            StepLast.Text = (int.Parse(StepLast.Text) - 1).ToString();
        }
    }
}
