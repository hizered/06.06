﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace zadacha_20._1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        int b = 0;
        public MainWindow()
        {
            InitializeComponent();
            for(char i = 'a'; i <= 'z';i++)
            {
                Knopki.Children.Add(new Button { Content = i, Height = 25, Width = 25, Name ="button" + i });
            }
            foreach (UIElement c in Knopki.Children)
            {
                if (c is Button)
                {
                    ((Button)c).Click += Button_Click;
                }
            }
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            char s = (char)((Button)e.OriginalSource).Content;
            if(s == 'a') resultFive.Text += "•−";
            else if (s == 'b') resultFive.Text += "−•••";
            else if (s == 'c') resultFive.Text += "−•−•";
            else if (s == 'd') resultFive.Text += "−••";
            else if (s == 'e') resultFive.Text += "•";
            else if (s == 'f') resultFive.Text += "••−•";
            else if (s == 'g') resultFive.Text += "−−•";
            else if (s == 'h') resultFive.Text += "••••";
            else if (s == 'i') resultFive.Text += "••";
            else if (s == 'j') resultFive.Text += "•−−−";
            else if (s == 'k') resultFive.Text += "−•−";
            else if (s == 'l') resultFive.Text += "•−••";
            else if (s == 'm') resultFive.Text += "−−";
            else if (s == 'n') resultFive.Text += "−•";
            else if (s == 'o') resultFive.Text += "−−−";
            else if (s == 'p') resultFive.Text += "•−−•";
            else if (s == 'u') resultFive.Text += "••−";
            else if (s == 'v') resultFive.Text += "•••−";
            else if (s == 'w') resultFive.Text += "•••−";
            else if (s == 'x') resultFive.Text += "−••−";
            else if (s == 'y') resultFive.Text += "−•−−";
            else if (s == 'z') resultFive.Text += "−−••";
            
        }
        private void FirstButton_Click(object sender, RoutedEventArgs e)
        {

            if (b == 0)
            {
                SecondTextBox.Text = firstTextBox.Text;
                b = 1;
                firstTextBox.Clear();
                FirstButton.Content = "<-";
            }
            else
            {
                firstTextBox.Text = SecondTextBox.Text;
                FirstButton.Content = "->";
                SecondTextBox.Clear();
                b = 0;
            }
            
        }

        private void vtoroeZadanie_Click(object sender, RoutedEventArgs e)
        {
            int firstNumber = int.Parse(FirstNumber.Text);
            int secondNumber = int.Parse(SecondNumber.Text);
            SumBox.Text = Convert.ToString(firstNumber + secondNumber);
            raznost.Text = Convert.ToString(firstNumber - secondNumber);
            proizvedenie.Text = Convert.ToString(firstNumber * secondNumber);
            if (secondNumber == 0)
            {
                MessageBox.Show("На ноль делить нельзя");
                chastnoe.Text = "Ошибка";
            }
            else chastnoe.Text = Convert.ToString(firstNumber / secondNumber);
        }

        private void fourCheck_Click(object sender, RoutedEventArgs e)
        {
            if (fourCheck.IsChecked == false)
            {
                FourTextBox.IsEnabled = false;
            }
            else if (FourTextBox.IsEnabled == true)
            {
                FourTextBox.IsEnabled = true;
            }
        }

        private void freeCheck_Click(object sender, RoutedEventArgs e)
        {
            if (freeCheck.IsChecked == false)
            {
                FreeTextBox.IsEnabled = false;
            }
            else if (freeCheck.IsEnabled == true)
            {
                FreeTextBox.IsEnabled = true;
            }
        }

        private void SecondCheck_Click(object sender, RoutedEventArgs e)
        {
            if (SecondCheck.IsChecked == false)
            {
                SeecondTextBox.IsEnabled = false;
            }
            else if (SecondCheck.IsEnabled == true)
            {
                SeecondTextBox.IsEnabled = true;
            }
        }

        private void FirstCheck_Click(object sender, RoutedEventArgs e)
        {
            if (FirstCheck.IsChecked == false)
            {
                FirstTextBox.IsEnabled = false;
            }
            else if (FirstCheck.IsEnabled == true)
            {
                FirstTextBox.IsEnabled = true;
            }
        }



        private void Plus_Click(object sender, RoutedEventArgs e)
        {
            int A = int.Parse(Afirst.Text);
            int B = int.Parse(Bfirst.Text);
            resultFree.Clear();
            resultFree.Text = Convert.ToString (A + B);
        }

        private void Minus_Click(object sender, RoutedEventArgs e)
        {
            int A = int.Parse(Afirst.Text);
            int B = int.Parse(Bfirst.Text);
            resultFree.Clear();
            resultFree.Text = Convert.ToString(A - B);
        }

        private void Star_Click(object sender, RoutedEventArgs e)
        {
            int A = int.Parse(Afirst.Text);
            int B = int.Parse(Bfirst.Text);
            resultFree.Clear();
            resultFree.Text = Convert.ToString(A * B);
        }
    }

}
